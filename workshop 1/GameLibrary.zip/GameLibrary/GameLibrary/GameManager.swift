//
//  GameManager.swift
//  GameLibrary
//
//  Created by Johnson, Lexline on 9/24/26.
//

import Foundation
internal import Combine

class GameManager: ObservableObject {
    @Published var games: Games?
    
    init() {
        loadGames()
    }
    
    func loadGames() {
        guard let url = Bundle.main.url(forResource: "games", withExtension: "json") else { return }
        
        do {
            let data = try Data(contentsOf: url)
            let decoder = JSONDecoder()
            games = try decoder.decode(Games.self, from: data)
        } catch {
            print("There was an error decoding: \(error)")
        }
    }
}
