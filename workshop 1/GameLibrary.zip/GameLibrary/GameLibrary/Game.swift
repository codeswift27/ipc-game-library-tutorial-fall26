//
//  Game.swift
//  GameLibrary
//
//  Created by Johnson, Lexline on 9/24/26.
//

import Foundation

struct Games: Codable {
    var games: [Game]
}

struct Game: Codable {
    var id: Int
    var title: String
    var releaseDate: String
    var rating: String
    var genres: [String]
    var description: String
    var image: String
}
