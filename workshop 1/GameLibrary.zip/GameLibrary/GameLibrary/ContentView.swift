//
//  ContentView.swift
//  GameLibrary
//
//  Created by Johnson, Lexline on 9/24/26.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var gameManager: GameManager
    let games: [String] = ["game 1", "game 2", "game 3", "game 4", "game 5"]
    let columns = [
        GridItem(.adaptive(minimum: 80))
    ]
    var body: some View {
        VStack(alignment: .leading) {
            Text("Discover")
                .font(.largeTitle)
                .bold()
            ScrollView {
                if gameManager.games != nil {
                    LazyVGrid(columns: columns) {
                        ForEach(games, id: \.self) { game in
                            Text(game)
                        }
                    }
                } else {
                    Text("no games")
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .padding()
    }
}

#Preview {
    @Previewable @StateObject var gameManager = GameManager()
    ContentView()
        .environmentObject(gameManager)
}
