//
//  GameLibraryApp.swift
//  GameLibrary
//
//  Created by Johnson, Lexline on 9/24/26.
//

import SwiftUI

@main
struct GameLibraryApp: App {
    @StateObject var gameManager = GameManager()
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(gameManager)
        }
    }
}
